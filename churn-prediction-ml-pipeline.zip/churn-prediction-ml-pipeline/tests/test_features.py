
import pandas as pd
from src.features import build_feature_matrix

def test_one_hot_columns():
    df = pd.DataFrame({
        "tenure_months":[1,2],
        "monthly_spend":[10.0,20.0],
        "num_support_tickets":[0,1],
        "plan":["Basic","Pro"],
        "region":["TX","CA"],
        "payment_type":["Card","ACH"]
    })
    X = build_feature_matrix(df)
    assert "plan_Pro" in X.columns
    assert "region_TX" in X.columns or "region_CA" in X.columns
