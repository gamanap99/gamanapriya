
import pandas as pd
from sklearn.linear_model import LogisticRegression

def test_model_fit():
    X = pd.DataFrame({"a":[0,1,0,1], "b":[1,1,0,0]})
    y = [0,1,0,1]
    m = LogisticRegression()
    m.fit(X,y)
    assert hasattr(m, "coef_")
