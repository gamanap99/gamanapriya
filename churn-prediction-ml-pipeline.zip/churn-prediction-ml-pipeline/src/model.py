
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, classification_report

def build_model(cfg: dict):
    mtype = cfg["model"]["type"]
    params = cfg["model"]["params"]
    if mtype == "logistic_regression":
        return LogisticRegression(**params)
    raise ValueError(f"Unknown model type: {mtype}")

def evaluate(model, X_test, y_test):
    prob = model.predict_proba(X_test)[:,1]
    auc = roc_auc_score(y_test, prob)
    return {"roc_auc": float(auc), "report": classification_report(y_test, (prob>0.5).astype(int))}
