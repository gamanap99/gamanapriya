
import os, json, yaml, joblib
from src.data import load_data, train_test
from src.features import build_feature_matrix, feature_order
from src.model import build_model, evaluate

def main(cfg_path="configs/config.yaml"):
    cfg = yaml.safe_load(open(cfg_path))
    raw = cfg["data"]["raw_csv"]
    target = cfg["data"]["target"]
    test_size = cfg["data"]["test_size"]
    random_state = cfg["data"]["random_state"]

    X, y = load_data(raw, target)
    X = build_feature_matrix(X)
    X_train, X_test, y_train, y_test = train_test(X, y, test_size, random_state)

    model = build_model(cfg)
    model.fit(X_train, y_train)
    metrics = evaluate(model, X_test, y_test)

    art_dir = cfg["artifacts"]["dir"]
    os.makedirs(art_dir, exist_ok=True)
    joblib.dump(model, os.path.join(art_dir, cfg["artifacts"]["model_filename"]))
    json.dump(list(X.columns), open(os.path.join(art_dir, cfg["artifacts"]["features_filename"]), "w"))

    print("Training complete:", metrics)

if __name__ == "__main__":
    main()
