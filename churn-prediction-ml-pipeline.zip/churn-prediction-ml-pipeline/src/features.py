
import pandas as pd

NUMERIC = ["tenure_months", "monthly_spend", "num_support_tickets"]
CATEG  = ["plan", "region", "payment_type"]

def build_feature_matrix(X: pd.DataFrame):
    Xn = X.copy()
    # basic numeric fill
    for c in NUMERIC:
        if c in Xn.columns:
            Xn[c] = Xn[c].fillna(Xn[c].median())

    # simple one-hot for categoricals
    Xn = pd.get_dummies(Xn, columns=[c for c in CATEG if c in Xn.columns], drop_first=True)
    return Xn

def feature_order(df: pd.DataFrame):
    return list(df.columns)
