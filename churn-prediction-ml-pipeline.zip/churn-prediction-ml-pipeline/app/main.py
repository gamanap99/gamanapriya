
from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import json
import os

app = FastAPI(title="Churn Prediction API")

ART_DIR = os.environ.get("ARTIFACTS_DIR", "artifacts")
MODEL_PATH = os.path.join(ART_DIR, "model.pkl")
FSET_PATH  = os.path.join(ART_DIR, "features.json")

class Request(BaseModel):
    features: dict

def _load():
    model = joblib.load(MODEL_PATH)
    feat_order = json.load(open(FSET_PATH))
    return model, feat_order

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/predict")
def predict(req: Request):
    model, feat_order = _load()
    x = [req.features.get(name, 0) for name in feat_order]
    y = model.predict_proba([x])[0][1]
    return {"churn_probability": float(y)}
