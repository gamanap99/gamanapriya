
from datetime import datetime
from airflow import DAG
from airflow.operators.python import PythonOperator
import subprocess

def extract():
    print("noop - sample data already present")

def transform():
    print("noop - handled inside train script")

def train():
    subprocess.run(["python", "src/train.py", "--config", "configs/config.yaml"], check=True)

with DAG(
    dag_id="churn_daily",
    start_date=datetime(2024,1,1),
    schedule_interval="@daily",
    catchup=False,
) as dag:
    t1 = PythonOperator(task_id="extract", python_callable=extract)
    t2 = PythonOperator(task_id="transform", python_callable=transform)
    t3 = PythonOperator(task_id="train", python_callable=train)

    t1 >> t2 >> t3
